import express from "express";
import authRoutes from "../api/auth/auth.router";
import otpVerificationRoutes from "../api/otp-verification/otp-verification.router";
import accountTypeRoutes from "../api/account-type/account-type.router";
import businessAboardRoutes from "../api/business-aboard/business-aboard.router";
import businessConfirmationRoutes from "../api/business-confirmation/business-confirmation.router";
import businessTradeRoutes from "../api/business-trade/business-trade.router";
import countryBusinessRoutes from "../api/country-business/country-business.router";
import companyInformationRoutes from "../api/company-information/company-information.router";
import transactionHistoryRoutes from "../api/transaction-history/transaction-history.router";
import merchantCategoryRoutes from "../api/merchant-category/merchant-category.router";
import userRoutes from "../api/user/user.router";
import stripeRoutes from "../api/stripe/stripe.router";

import expressAsyncHandler from "express-async-handler";
import countryStateCityController from "../api/country-state-city/country-state-city.controller";

const router = express.Router();

router
  .use("/auth", authRoutes)
  .use("/otp-verification", otpVerificationRoutes)
  .use("/countries", expressAsyncHandler(countryStateCityController.getCountry))
  .use("/states", expressAsyncHandler(countryStateCityController.getState))
  .use("/cities", expressAsyncHandler(countryStateCityController.getCity))
  .use("/account-type", accountTypeRoutes)
  .use("/business-aboard", businessAboardRoutes)
  .use("/business-confirmation", businessConfirmationRoutes)
  .use("/business-trade", businessTradeRoutes)
  .use("/country-business", countryBusinessRoutes)
  .use("/merchant-category", merchantCategoryRoutes)
  .use("/company-information", companyInformationRoutes)
  .use("/transaction-history", transactionHistoryRoutes)
  .use("/user", userRoutes)
  .use("/stripe", stripeRoutes);

export default router;
