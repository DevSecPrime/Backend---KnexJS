import express from "express";
import DeleteAccountController from "../web/delete-account/delete-account-controller";
import expressAsyncHandler from "express-async-handler";
const router = express.Router();
import validator from "../common/config/validator.config";
import deleteAccountDto from "../web/delete-account/dto/delete-account.dto";

router
  .get("/", async (req, res) => {
    res.send("Website!");
  })
  .get("/api/changelogs", async (req, res) => {
    return res.render("api/changelog");
  })
  .get("/terms-and-condition", async (req, res) => {
    return res.render("pages/term-and-condition");
  })
  .get("/terms-of-service", async (req, res) => {
    return res.render("pages/terms-of-service");
  })
  .get("/help", async (req, res) => {
    return res.render("pages/help");
  })
  .get("/delete-account-success", async (req, res) => {
    return res.render("delete-account/respons");
  })
  .get("/support", async (req, res) => {
    return res.render("pages/support");
  })
  .get("/privacy-policy", async (req, res) => {
    return res.render("pages/privacy-policy");
  })
  .get("/delete-account", async (req, res) => {
    return res.render("pages/delete-account");
  });
// .get(
//   "/delete-account",
//   expressAsyncHandler(DeleteAccountController.deleteAccountPage)
// )
// .post(
//   "/delete-account/:userId",
//   validator.body(deleteAccountDto),
//   expressAsyncHandler(DeleteAccountController.deleteAccountRequest)
// );

export default router;
