export default class UserResource {
  constructor(data) {
    this.userId = data.id;
    this.email = data.email;
    this.countryCode = data.countryCode;
    this.phone = data.phone;
    this.otp = Number(data.otp);
    this.isOtpVerified = !!data.otpVerifiedAt;
    this.isLogin = data.isLogin;
  }
}
