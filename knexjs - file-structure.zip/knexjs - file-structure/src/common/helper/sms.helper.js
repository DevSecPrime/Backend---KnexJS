import twilio from "twilio";
import UnauthorizeException from "../../common/exceptions/unauthorize.exception";

require("dotenv").config();

export default async (data) => {
  const client = new twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );

  await client.messages
    .create({
      body: `Dear customer,
${data.otp} is your one time password (OTP). Please do not share the OTP with others.
Regards,
Team ${process.env.APP_NAME}`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: data.phone,
    })
    .then((res) => console.log(res.body))
    .catch((error) => {
      console.log(error);
      throw new UnauthorizeException("Invalid phone number");
    });
};
