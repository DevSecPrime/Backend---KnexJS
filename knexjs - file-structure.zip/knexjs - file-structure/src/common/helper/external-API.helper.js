import axios from "axios";

/**
 *  Get Company Information With Number
 * @param tokens
 * @param payload
 */
export const getCompanyInformationWithNumber = async (number) => {
  if (number) {
    try {
      const data = await axios.get(
        "https://api.company-information.service.gov.uk/company/" + number,
        {
          headers: {
            Authorization: `72dfb815-648c-422d-80fa-2a3e32401a84`,
          },
        }
      );
      return data.data;
    } catch (error) {
      console.error(error);
    }
  }
};

/**
 *  Get Company Information With Name
 * @param tokens
 * @param payload
 */
export const getCompanyInformationWithName = async (name) => {
  if (name) {
    try {
      const data = await axios.get(
        "https://api.company-information.service.gov.uk/search?q=" +
          name +
          "&items_per_page=50&start_index=0",
        {
          headers: {
            Authorization: `72dfb815-648c-422d-80fa-2a3e32401a84`,
          },
        }
      );

      console.log(data.data);

      return data.data;
    } catch (error) {
      console.error(error);
    }
  }
};
