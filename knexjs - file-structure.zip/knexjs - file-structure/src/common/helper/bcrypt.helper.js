import bcrypt from "bcrypt";

export const encodeString = (password) => {
  const SALT = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(password, SALT);
};

export const compareString = (string, hashString) => {
  return bcrypt.compareSync(string, hashString);
};
