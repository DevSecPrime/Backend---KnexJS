import { HTTP_STATUS_CODE } from "../constants";
import GeneralError from "./general-error";

class BadRequestException extends GeneralError {
  constructor(message) {
    super();
    this.message = message;
    this.status = HTTP_STATUS_CODE.BAD_REQUEST;
  }
}

export default BadRequestException;
