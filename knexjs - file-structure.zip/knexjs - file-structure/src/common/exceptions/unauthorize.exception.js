import { HTTP_STATUS_CODE } from "../constants";
import GeneralError from "./general-error";

class UnauthorizeException extends GeneralError {
  constructor(message) {
    super();
    this.message = message || "Unauthenticated.";
    this.status = HTTP_STATUS_CODE.UNAUTHORIZE;
  }
}

export default UnauthorizeException;
