import { HTTP_STATUS_CODE } from "../constants";
import GeneralError from "./general-error";

class ConflictException extends GeneralError {
  constructor(message) {
    super();
    this.message = message;
    this.status = HTTP_STATUS_CODE.CONFLICT;
  }
}

export default ConflictException;
