module.exports.STORAGE_PATH = "public/storage";

module.exports.DEFAULT_PAGE = 1;
module.exports.PER_PAGE = 10;

module.exports.ACCOUNT_TYPE = {
  BUSINESS: "Business",
  INDIVIDUAL: "Individual",
};
module.exports.HTTP_STATUS_CODE = {
  BAD_REQUEST: 400,
  UNAUTHORIZE: 401,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE: 422,
  INTERNAL_SERVER: 500,
};

module.exports.DELETE_ACCOUNT_TYPE = {
  TEMPORARY: "temporary",
  PERMANENT: "permanent",
};

module.exports.DEVICE_TYPE = {
  IOS: "iOS",
  ANDROID: "Android",
};

module.exports.MEDIA_EXTENSIONS = {
  IMAGE: "jpg",
  VIDEO: "mp4",
};

module.exports.APP_VERSIONS_STATUS = {
  UPTODATE: 0,
  OUTDATED: 1,
  OPTIONAL: 2,
};
