import { HTTP_STATUS_CODE } from "../constants";
import GeneralError from "../exceptions/general-error";

export default (err, req, res, next) => {
  if (err instanceof GeneralError) {
    return res.status(err.status).json({ message: err.message });
  }

  if (err && err.error && err.error.isJoi) {
    if (err.error.details[0]) {
      return res.status(HTTP_STATUS_CODE.UNPROCESSABLE).json({
        message: err.error.details[0].message,
      });
    }
  }

  if (err.statusCode) {
    return res.status(err.statusCode).json({ message: err.message });
  } else {
    return res
      .status(HTTP_STATUS_CODE.INTERNAL_SERVER)
      .json({ message: err.message });
  }
};
