class WebController {}

export default new WebController();
