import { compareString } from "../../common/helper/common.helper";
import DeleteAccountService from "./delete-account.service";

class DeleteAccountController {
  /**
   * delete account page
   * @param {*} req
   * @param {*} res
   * @returns
   */
  static async deleteAccountPage(req, res) {
    const email = req.query.email.replace(" ", "+");
    const user = await DeleteAccountService.findUserByEmail(email);
    if (!user) {
      throw new Error("User Not found");
    }
    if (compareString(user.id.toString(), req.query.token)) {
      const deleteAccountUrl = `${process.env.APP_URL}/delete-account?token=${req.query.token}&phone=${user.phone}`;
      return res.render("delete-account/index", { user, deleteAccountUrl });
    }
    throw new Error("User Not found");
  }

  /**
   * delete account request save
   * @param {*} req
   * @param {*} res
   */
  static async deleteAccountRequest(req, res) {
    await DeleteAccountService.deleteAccountRequest(
      req.body,
      req.params.userId
    );
    res.render("delete-account/respons");
  }
}
export default DeleteAccountController;
