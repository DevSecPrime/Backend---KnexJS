import Joi from "joi";

export default Joi.object({
  type: Joi.string().valid("temporary", "permanent").required().messages({
    "string.empty": "The type field is required.",
    "any.only": "Please select any of the type for delete account",
  }),
  reason: Joi.string()
    .required()
    .messages({ "string.empty": "The reason field is required." }),
});
