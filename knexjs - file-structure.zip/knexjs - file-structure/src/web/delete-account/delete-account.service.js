import knex from "../../common/config/database.config";

class DeleteAccountService {
  /**
   * get user using Emailr
   * @param {string} phone
   * @returns
   */
  static async findUserByEmail(email) {
    return knex("users").where("email", email).first();
  }

  /**
   * delete account request save
   * @param {*} body
   * @param {*} userId
   */
  static async deleteAccountRequest(body, userId) {
    await knex("account_delete_requests").insert({
      type: body.type,
      reason: body.reason,
      userId,
    });
    return true;
  }
}
export default DeleteAccountService;
