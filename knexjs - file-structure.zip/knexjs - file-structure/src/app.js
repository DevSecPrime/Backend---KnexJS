import dotenv from "dotenv";
dotenv.config();
import express from "express";
import { createServer as httpCreateServer } from "http";
import { createServer as httpsCreateServer } from "https";
import morgan from "morgan";

import swaggerConfig from "./common/config/swagger.config";
import firebaseAdmin from "firebase-admin";
import errorHandlerMiddleware from "./common/middleware/error-handler.middleware";
import path from "path";
import fs from "fs";
import passport from "passport";
import "./common/passport/jwt.strategy";
import apiRouter from "./routes/api.router";
import webRouter from "./routes/web.router";
import fileUpload from "express-fileupload";

import session from "express-session";

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(passport.initialize());
app.use(express.static(path.join(__dirname, "../public")));
app.use(fileUpload());
app.use(morgan("dev"));
app.use(
  session({ secret: "hjs8sad19d", resave: "false", saveUninitialized: "true" })
);
app.set("view engine", "ejs");
app.set("views", path.join(`${__dirname}../../src`, "views"));

firebaseAdmin.initializeApp({
  credential: firebaseAdmin.credential.applicationDefault(),
});

app.use("/api/v1", apiRouter);
app.use("/", webRouter);
app.use("/api/documentation", swaggerConfig);
app.use(errorHandlerMiddleware);

//The 404 Route (ALWAYS Keep this as the last route)
app.get("*", function (req, res) {
  res.send("Page Not Found");
});

const isSecure = process.env.IS_SECURE === "true";
let server;
if (isSecure) {
  var options = {
    key: fs.readFileSync(`${process.env.SSL_CERT_BASE_PATH}/privkey.pem`),
    cert: fs.readFileSync(`${process.env.SSL_CERT_BASE_PATH}/cert.pem`),
    ca: [
      fs.readFileSync(`${process.env.SSL_CERT_BASE_PATH}/cert.pem`),
      fs.readFileSync(`${process.env.SSL_CERT_BASE_PATH}/fullchain.pem`),
    ],
  };
  server = httpsCreateServer(options, app);
} else {
  server = httpCreateServer(app);
}

server.listen(process.env.PORT, () => {
  console.log(`Server is running on ${process.env.PORT}`);
});
