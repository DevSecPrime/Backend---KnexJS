import countryStateCityService from "./country-state-city.service";

class CountyStateCityController {
  /**
   * Get Country List
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getCountry(req, res) {
    const data = await countryStateCityService.getCountry();

    console.log(data);
    return res.send({
      data,
    });
  }

  /**
   * Get Country wise State List
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getState(req, res) {
    const data = await countryStateCityService.getState(req.query);

    return res.send({
      data,
    });
  }

  /**
   * Get State Wise City list
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getCity(req, res) {
    const data = await countryStateCityService.getCities(req.query);

    return res.send({
      city: data.data,
    });
  }
}
export default new CountyStateCityController();
