import { DEFAULT_PAGE, PER_PAGE } from "../../common/constants";
import knex from "../../common/config/database.config";

class CountyStateCityServices {
  /**
   * Get Country List
   * @param {object} query
   * @returns
   */
  async getCountry() {
    // if (query.search) {
    //   return await knex("countries").whereILike("name", `%${query.search}%`);
    //   // .paginate({
    //   //   perPage: limit,
    //   //   currentPage: page,
    //   //   isLengthAware: true,
    //   // });
    // }

    console.log("+===========+++++++COuntry ====++++++++++++");
    console.log(await knex("countries"));
    return await knex("countries");
    // .paginate({
    //   perPage: limit,
    //   currentPage: page,
    //   isLengthAware: true,
    // });
  }

  /**
   * Get Country wise State List
   * @param {object} query
   * @returns
   */
  async getState(query) {
    // const limit = query.limit ? parseInt(query.limit, 10) : PER_PAGE;
    // const page = query.page ? parseInt(query.page, 10) : DEFAULT_PAGE;

    // if (query.search) {
    //   return await knex("states")
    //     .where({
    //       countryCode: query.countryCode,
    //     })
    //     .whereILike("name", `%${query.search}%`);

    //   // .paginate({
    //   //   perPage: limit,
    //   //   currentPage: page,
    //   //   isLengthAware: true,
    //   // });
    // }
    console.log(query.countryCode);
    return await knex("states").where({
      countryCode: query.countryCode,
    });
    // .paginate({
    //   perPage: limit,
    //   currentPage: page,
    //   isLengthAware: true,
    // });
  }

  /**
   * Get State wise City List
   * @param {object} query
   * @returns
   */
  async getCities(query) {
    const limit = query.limit ? parseInt(query.limit, 10) : PER_PAGE;
    const page = query.page ? parseInt(query.page, 10) : DEFAULT_PAGE;

    if (query.search) {
      return await knex("cities")
        .where({
          countryCode: query.countryCode,
          stateCode: query.stateCode,
        })
        .whereILike("name", `%${query.search}%`)
        .paginate({
          perPage: limit,
          currentPage: page,
          isLengthAware: true,
        });
    }

    return await knex("cities")
      .where({
        countryCode: query.countryCode,
        stateCode: query.stateCode,
      })
      .paginate({
        perPage: limit,
        currentPage: page,
        isLengthAware: true,
      });
  }
}
export default new CountyStateCityServices();
