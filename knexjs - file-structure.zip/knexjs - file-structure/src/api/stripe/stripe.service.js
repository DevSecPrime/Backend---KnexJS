import knex from "../../common/config/database.config";
import moment from "moment";
import Stripe from "stripe";
import userService from "../user/user.service";

class StripeServices {
  async getConnectionToken(headers) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    console.log(key);

    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);
    return await stripe.terminal.connectionTokens.create();
  }

  async postPaymentIntents(headers, body, user) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    const stripe = new Stripe(`${key}`);

    let FIXED_FEE = 0.1;
    let PERCENTAGE_FEE = 0.014;

    let MOVENEY_PERCENTAGE_FEE = 0.005;

    let stripeTax = (Number(body.amount) * PERCENTAGE_FEE + FIXED_FEE).toFixed(
      2
    );

    let moveneyFees = Number(
      Number(body.amount) * MOVENEY_PERCENTAGE_FEE + 0.05
    ).toFixed(2);

    let totalApplicationFee = Number(stripeTax) + Number(moveneyFees);

    if (body.destinationId) {
      try {
        const paymentDetails = await stripe.paymentIntents.create({
          amount: Number(body.amount).toFixed(0) * 100,
          currency: "gbp",
          payment_method_types: ["card_present"],
          capture_method: "automatic",
          transfer_data: {
            // destination: userDetails.stripeConnectAccountId,
            destination: body.destinationId,
            // "acct_1N5SkzPQmgQhVEqB"
            // amount: parseInt(body.amount) * 100 - 10,
          },
          application_fee_amount: Number(totalApplicationFee * 100).toFixed(0),
        });

        const [id] = await knex("transaction_history").insert({
          userId: user.id,
          productIds: body.productIds,
          notes: body.notes,
          status: body.status,
          amount: Number(body.amount).toFixed(0),
          currency: paymentDetails.currency,
          stripePaymentId: paymentDetails.id,
          moveneyFees: moveneyFees,
          totalApplicationFees: totalApplicationFee,
          stripeTax: stripeTax,
          paymentStatus: "credit",
          stripeConnectAccountId: body.destinationId,
        });

        return paymentDetails;
      } catch (error) {
        return error;
      }
    }
    return false;
  }

  async getCapture(headers, body) {
    try {
      let key =
        headers.stripemode == "staging"
          ? process.env.STRIPE_KEY
          : process.env.STRIPE_PRODUCTION_KEY;

      const stripe = new Stripe(`${key}`);
      // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

      return await stripe.paymentIntents.capture(body.paymentIntentsId);
    } catch (error) {
      console.log(error);
    }
  }

  async deleteAccount(headers, body) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    console.log(key);

    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    return await stripe.accounts.del(body.number);
  }

  async listAccount(headers) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    console.log(key);

    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    const list = await stripe.accounts.list({
      limit: 100,
    });

    return await Promise.all(
      list.data.map(async (data) => {
        if (data.payouts_enabled === false) {
          await stripe.accounts.del(data.id);
          return {
            id: data.id,
            payouts_enabled: data.payouts_enabled,
          };
        }
      })
    );
  }
}
export default new StripeServices();
