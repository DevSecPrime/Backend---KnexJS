import { Router } from "express";

import expressAsyncHandler from "express-async-handler";
import stripeController from "./stripe.controller";
import paymentIntentsValidation from "./dtos/payment-Intents.dto";
import validator from "../../common/config/validator.config";
import authenticateMiddleware from "../../common/middleware/authenticate.middleware";

const router = Router();

router.get(
  "/connection-token",
  authenticateMiddleware,
  expressAsyncHandler(stripeController.getConnectionToken)
);

router.post(
  "/payment-intents",
  authenticateMiddleware,
  validator.body(paymentIntentsValidation),
  expressAsyncHandler(stripeController.postPaymentIntents)
);

router.get("/capture", expressAsyncHandler(stripeController.getCapture));

router.delete(
  "/delete-account",
  authenticateMiddleware,
  expressAsyncHandler(stripeController.deleteAccount)
);

router.get(
  "/account-list",
  authenticateMiddleware,
  expressAsyncHandler(stripeController.listAccount)
);
export default router;
