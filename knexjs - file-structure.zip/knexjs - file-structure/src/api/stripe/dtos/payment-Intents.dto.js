import Joi from "joi";

const schema = Joi.object({
  amount: Joi.string().required().messages({
    "string.empty": "The amount field is required.",
  }),
  destinationId: Joi.string().required().messages({
    "string.empty": "The destination field is required.",
  }),
  productIds: Joi.optional().messages({
    "string.empty": "The product ids field is required.",
  }),
  notes: Joi.optional().messages({
    "string.empty": "The notes field is required.",
  }),
});

export default schema;
