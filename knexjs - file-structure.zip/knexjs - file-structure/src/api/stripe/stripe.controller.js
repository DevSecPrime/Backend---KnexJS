import stripeService from "./stripe.service";

class StripeController {
  /**
   * Get Merchant Category
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getConnectionToken(req, res) {
    const data = await stripeService.getConnectionToken(req.headers);
    return res.send({ data });
  }

  async postPaymentIntents(req, res) {
    const data = await stripeService.postPaymentIntents(
      req.headers,
      req.body,
      req.user
    );
    if (data === false) {
      return res.status(400).send({ message: "something went wrong" });
    }
    return res.send({ data });
  }

  async getCapture(req, res) {
    const data = await stripeService.getCapture(req.headers, req.query);
    return res.send({ data });
  }

  async deleteAccount(req, res) {
    const data = await stripeService.deleteAccount(req.headers, req.query);
    return res.send({ data });
  }

  async listAccount(req, res) {
    const data = await stripeService.listAccount(req.headers);
    return res.send({ data });
  }
}
export default new StripeController();
