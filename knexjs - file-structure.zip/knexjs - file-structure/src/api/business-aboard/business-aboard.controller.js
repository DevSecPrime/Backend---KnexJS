import businessAboardService from "./business-aboard.service";

class BusinessAboardController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getBusinessAboard(req, res) {
    const businessAboardList = await businessAboardService.getBusinessAboard();
    const footerTitle =
      "My company does not have any presence outside of United Kingdom.";

    const data = {
      businessAboardList,
      footerTitle,
    };

    return res.send({ data });
  }
}
export default new BusinessAboardController();
