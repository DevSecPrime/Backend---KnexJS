import knex from "../../common/config/database.config";
import moment from "moment";
import BadRequestException from "../../common/exceptions/bad-request.exception";

class BusinessAboardServices {
  /**
   * Get Account Type
   * @returns
   */
  async getBusinessAboard() {
    return await knex("business_aboard");
  }
}
export default new BusinessAboardServices();
