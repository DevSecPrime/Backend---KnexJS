import { Router } from "express";
import businessAboardController from "./business-aboard.controller";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router.get(
  "/",
  expressAsyncHandler(businessAboardController.getBusinessAboard)
);
export default router;
