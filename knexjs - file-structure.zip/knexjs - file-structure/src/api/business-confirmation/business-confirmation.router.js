import { Router } from "express";
// import businessAboardController from "./business-confirmation.controller";
import businessConfirmationController from "./business-confirmation.controller";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router.get(
  "/",
  expressAsyncHandler(businessConfirmationController.getBusinessConfirmation)
);
export default router;
