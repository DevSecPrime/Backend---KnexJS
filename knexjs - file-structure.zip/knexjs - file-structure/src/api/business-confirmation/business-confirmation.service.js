import knex from "../../common/config/database.config";

class BusinessConfirmationServices {
  /**
   * Get the business confirmation
   * @returns
   */
  async getBusinessConfirmation() {
    return await knex("business_confirmation");
  }
}
export default new BusinessConfirmationServices();
