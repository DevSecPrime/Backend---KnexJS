import businessConfirmationService from "./business-confirmation.service";

class BusinessAboardController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getBusinessConfirmation(req, res) {
    const businessConfirmation =
      await businessConfirmationService.getBusinessConfirmation();

    const data = await Promise.all(
      await businessConfirmation.map(async (data) => {
        return {
          id: data.id,
          description: data.description,
          highlightText: data.highlightText,
          restrictedTitle: data.restrictedTitle,
          restrictedDescription: data.restrictedDescription,
          restrictedDetails: data.restrictedDetails
            ? data.restrictedDetails.split(",")
            : null,
        };
      })
    );

    return res.send({ data });
  }
}
export default new BusinessAboardController();
