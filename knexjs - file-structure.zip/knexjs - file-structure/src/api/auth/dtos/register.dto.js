import Joi from "joi";

export default Joi.object({
  email: Joi.string().email().required().messages({
    "string.empty": "The email field is required.",
    "string.email": "The email must be a valid email.",
  }),
  countryCode: Joi.string().required().messages({
    "string.empty": "The country code field is required.",
  }),
  phone: Joi.string().required().messages({
    "string.empty": "The phone number field is required.",
  }),
});
