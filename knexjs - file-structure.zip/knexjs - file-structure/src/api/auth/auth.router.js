import express from "express";
import AuthController from "./auth.controller";
import validator from "../../common/config/validator.config";
import expressAsyncHandler from "express-async-handler";
import registerDto from "./dtos/register.dto";

const router = express.Router();

router.post(
  "/register",
  validator.body(registerDto),
  expressAsyncHandler(AuthController.register)
);

export default router;
