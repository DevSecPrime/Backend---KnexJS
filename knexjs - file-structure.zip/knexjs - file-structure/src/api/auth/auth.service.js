import moment from "moment";
import sendSms from "../../common/helper/sms.helper";
import accessTokensService from "../access-tokens/access-tokens.service";
import refreshTokensService from "../refresh-tokens/refresh-tokens.service";
import { decode } from "jsonwebtoken";
import userService from "../user/user.service";

class AuthService {
  /**
   * register user
   * @param {object} body
   */
  async register(body) {
    let user = await userService.findOne(
      body.email,
      body.countryCode,
      body.phone
    );
    if (user) {
      const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;

      user = await userService.createOrUpdate(
        {
          otp,
          otpExpiredAt: await moment()
            .add(2, "minutes")
            .format("YYYY-MM-DD HH:mm:ss"),
          otpVerifiedAt: null,
        },
        user.id
      );
      await sendSms({ otp, phone: `${user.countryCode}${user.phone}` });

      return { ...user, isLogin: true };
    } else {
      let temporaryUser = await userService.findOneTemporaryUser(
        body.email,
        body.countryCode,
        body.phone
      );
      if (!temporaryUser) {
        temporaryUser = await userService.createOrUpdateTemporaryUser(body);
      }
      const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;

      temporaryUser = await userService.createOrUpdateTemporaryUser(
        {
          otp,
          otpExpiredAt: await moment()
            .add(2, "minutes")
            .format("YYYY-MM-DD HH:mm:ss"),
          otpVerifiedAt: null,
        },
        temporaryUser.id
      );

      await sendSms({
        otp,
        phone: `${temporaryUser.countryCode}${temporaryUser.phone}`,
      });

      return { ...temporaryUser, isLogin: false };
    }
  }

  /**
   * Generate access token & refresh token
   * @param {number} userId
   * @param {string} email
   */
  async generateTokenPairs(userId, email) {
    const accessToken = await accessTokensService.createToken(userId, email);

    const decodedToken = decode(accessToken);

    const refreshToken = await refreshTokensService.createToken(
      decodedToken.jti,
      decodedToken.exp
    );

    return {
      accessToken,
      refreshToken,
      expireAt: decodedToken.exp,
    };
  }
}

export default new AuthService();
