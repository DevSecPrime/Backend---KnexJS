import authService from "./auth.service";
import { encodeString } from "../../common/helper/bcrypt.helper";
import UserResource from "../../resource/user.resource";
import knex from "../../common/config/database.config";

class AuthController {
  /**
   * user register
   * @param {object} req
   * @param {object} res
   */
  async register(req, res) {
    const user = await authService.register(req.body);

    return res.json({
      data: {
        ...new UserResource(user),
      },
      message: "Please check otp send on your phone number.",
    });
  }
}

export default new AuthController();
