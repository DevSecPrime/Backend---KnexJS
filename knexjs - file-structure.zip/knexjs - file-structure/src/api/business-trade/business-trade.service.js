import knex from "../../common/config/database.config";

class BusinessTradeServices {
  /**
   * Get the business Trade
   * @returns
   */
  async getBusinessTrade() {
    return await knex("business_trade");
  }
}
export default new BusinessTradeServices();
