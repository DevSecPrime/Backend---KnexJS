import businessTradeService from "./business-trade.service";

class BusinessAboardController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getBusinessTrade(req, res) {
    const data = await businessTradeService.getBusinessTrade();

    return res.send({ data });
  }
}
export default new BusinessAboardController();
