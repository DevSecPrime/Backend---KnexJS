import { Router } from "express";
// import businessAboardController from "./business-Trade.controller";
import businessTradeController from "./business-trade.controller";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router.get("/", expressAsyncHandler(businessTradeController.getBusinessTrade));
export default router;
