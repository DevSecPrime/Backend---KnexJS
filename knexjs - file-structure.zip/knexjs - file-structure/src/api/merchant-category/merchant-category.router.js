import { Router } from "express";

import expressAsyncHandler from "express-async-handler";
import merchantCategoryController from "./merchant-category.controller";

const router = Router();

router.get(
  "/",
  expressAsyncHandler(merchantCategoryController.getMerchantCategory)
);
export default router;
