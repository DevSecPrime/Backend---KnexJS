import merchantCategoryService from "./merchant-category.service";

class MerchantCategoryController {
  /**
   * Get Merchant Category
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getMerchantCategory(req, res) {
    const data = await merchantCategoryService.getMerchantCategory();
    return res.send({ data });
  }
}
export default new MerchantCategoryController();
