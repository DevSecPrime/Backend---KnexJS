import knex from "../../common/config/database.config";
import moment from "moment";

class MerchantCategoryServices {
  /**
   * Get Merchant Category
   * @returns
   */
  async getMerchantCategory() {
    return await knex("merchant_category");
  }
}
export default new MerchantCategoryServices();
