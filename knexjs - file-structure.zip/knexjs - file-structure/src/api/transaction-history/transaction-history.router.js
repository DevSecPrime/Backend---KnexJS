import { Router } from "express";
import transactionHistoryController from "./transaction-history.controller";
import expressAsyncHandler from "express-async-handler";
import authenticateMiddleware from "../../common/middleware/authenticate.middleware";

const router = Router();

router.get(
  "/",
  authenticateMiddleware,
  expressAsyncHandler(transactionHistoryController.getTransactionHistory)
);
export default router;
