import knex from "../../common/config/database.config";
import { DEFAULT_PAGE, PER_PAGE } from "../../common/constants";

class TransactionHistoryServices {
  /**
   *
   * @param {*} query
   * @param {*} user
   * @returns
   */
  async getTransactionHistory(query, user) {
    const limit = query.perPage ? parseInt(query.perPage, 10) : PER_PAGE;
    const page = query.page ? parseInt(query.page, 10) : DEFAULT_PAGE;

    return await knex("transaction_history")
      .where({
        userId: user.id,
      })
      .paginate({
        perPage: limit,
        currentPage: page,
        isLengthAware: true,
      });
  }
}
export default new TransactionHistoryServices();
