import transactionHistoryService from "./transaction-history.service";
import moment from "moment";

class CountryBusinessController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getTransactionHistory(req, res) {
    let { data, pagination: meta } =
      await transactionHistoryService.getTransactionHistory(
        req.query,
        req.user
      );

    if (data) {
      data = data.map(function (data) {
        return {
          ...data,
          productName: "",
          amount: Number(data.amount),
          stripeTax: Number(data.stripeTax),
          totalApplicationFees: Number(data.totalApplicationFees),
          moveneyFees: Number(data.moveneyFees),
          createdAt: moment(data.createdAt).unix(),
          updatedAt: moment(data.updatedAt).unix(),
        };
      });
    }

    return res.send({ data, meta });
  }
}
export default new CountryBusinessController();
