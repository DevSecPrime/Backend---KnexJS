import { Router } from "express";
import companyInformationController from "./company-information.controller";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router.get(
  "/",
  expressAsyncHandler(companyInformationController.getCompanyInformation)
);
export default router;
