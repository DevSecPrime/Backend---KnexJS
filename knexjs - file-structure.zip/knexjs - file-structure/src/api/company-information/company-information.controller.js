import companyInformationService from "./company-information.service";
import { getCompanyInformationWithName } from "../../common/helper/external-API.helper";

class CompanyInformationController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getCompanyInformation(req, res) {
    let data = await companyInformationService.getCompanyInformation(req.query);

    try {
      if (req.query.number) {
        let companyInformation = await getCompanyInformationWithName(
          data.company_name
        );

        let companyList = await Promise.all(
          await companyInformation.items.map(async (data) => {
            if (data.company_number == req.query.number) {
              return {
                companyName: data.title,
                companyNumber: data.company_number,
                companyStatus: data.company_status,
                description: data.description,
                address: data.address,
                addressSnippet: data.address_snippet,
              };
            }
          })
        );
        data = companyList.filter(function (el) {
          return el != null;
        });
      }

      if (req.query.name) {
        data = await Promise.all(
          await data.items.map(async (data) => {
            return {
              companyName: data.title,
              companyNumber: data.company_number,
              companyStatus: data.company_status,
              description: data.description,
              address: data.address,
              addressSnippet: data.address_snippet,
            };
          })
        );
      }
      return res.send({ data });
    } catch (error) {
      if (req.query.number) {
        return res.status(400).send({ message: "Invalid company number" });
      } else {
        return res.status(400).send({ message: "Invalid company name" });
      }
    }
  }
}
export default new CompanyInformationController();
