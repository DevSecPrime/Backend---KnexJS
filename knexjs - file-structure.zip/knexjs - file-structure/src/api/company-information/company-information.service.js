import knex from "../../common/config/database.config";
import moment from "moment";
import BadRequestException from "../../common/exceptions/bad-request.exception";
import {
  getCompanyInformationWithNumber,
  getCompanyInformationWithName,
} from "../../common/helper/external-API.helper";

class CompanyInformationServices {
  /**
   * Get Company Information
   * @param {object} req
   * @param {object} res
   */
  async getCompanyInformation(req) {
    const { number, name } = req;

    if (number) {
      return await getCompanyInformationWithNumber(number);
    } else {
      return await getCompanyInformationWithName(name);
    }
    return false;
  }
}
export default new CompanyInformationServices();
