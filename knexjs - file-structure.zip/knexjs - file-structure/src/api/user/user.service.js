import knex from "../../common/config/database.config";
import moment from "moment";
import BadRequestException from "../../common/exceptions/bad-request.exception";
import Stripe from "stripe";
import { uploadFile } from "../../common/helper/fileupload.helper";
import { STORAGE_PATH } from "../../common/constants";
import fs from "fs";
class UserServices {
  /**
   * Find User
   * @param {string} email
   * @param {string} countryCode
   * @param {string} phone
   * @returns
   */
  async findOne(email, countryCode, phone) {
    const isEmailRegister = await this.findByEmail(email);
    const isPhoneRegister = await this.findByPhone(countryCode, phone);

    if (isEmailRegister) {
      if (
        isEmailRegister.phone != phone ||
        isEmailRegister.countryCode != countryCode
      ) {
        throw new BadRequestException("Invalid phone number.");
      }
    }
    if (isPhoneRegister) {
      if (isPhoneRegister.email != email) {
        throw new BadRequestException("Invalid email address.");
      }
    }

    return await this.findByEmail(email);
  }

  /**
   * Find User
   * @param {string} email
   * @param {string} countryCode
   * @param {string} phone
   * @returns
   */
  async findOneTemporaryUser(email, countryCode, phone) {
    const isEmailRegister = await knex("temporary_users")
      .where({
        email,
      })
      .first();
    const isPhoneRegister = await await knex("temporary_users")
      .where({
        countryCode,
        phone,
      })
      .first();

    if (isEmailRegister) {
      if (
        isEmailRegister.phone != phone ||
        isEmailRegister.countryCode != countryCode
      ) {
        throw new BadRequestException(
          // "An account already exists with this phone number."
          "Invalid phone number."
        );
      }
    }
    if (isPhoneRegister) {
      if (isPhoneRegister.email != email) {
        throw new BadRequestException(
          "Invalid email address."
          // "An account already exists with this email address!"
        );
      }
    }

    return await knex("temporary_users")
      .where({
        email,
        countryCode,
        phone,
      })
      .first();
  }

  /**
   * Find By Phone
   * @param {string} countryCode
   * @param {string} phone
   * @returns
   */
  async findByPhone(countryCode, phone) {
    return await knex("users")
      .where({
        countryCode,
        phone,
      })
      .first();
  }

  /**
   * Find By Email
   * @param {string} email
   * @returns
   */
  async findByEmail(email) {
    return await knex("users")
      .where({
        email,
      })
      .first();
  }

  /**
   * FindById User
   * @param {number} id
   * @returns
   */
  async findById(id) {
    return await knex("users")
      .where({
        id,
      })
      .first();
  }

  /**
   * Create User
   * @param {string} email
   * @param {string} phone
   * @returns
   */
  async createOrUpdate(data, userId = "") {
    if (userId) {
      await knex("users")
        .update({ ...data })
        .where("id", userId);

      return this.findById(userId);
    }

    const [id] = await knex("users").insert({
      ...data,
    });
    return this.findById(id);
  }

  /**
   * Create Temporary User
   * @param {string} email
   * @param {string} phone
   * @returns
   */
  async createOrUpdateTemporaryUser(data, userId = "") {
    if (userId) {
      await knex("temporary_users")
        .update({ ...data })
        .where("id", userId);

      return await knex("temporary_users").where("id", userId).first();
    }

    const [id] = await knex("temporary_users").insert({
      ...data,
    });
    return await knex("temporary_users").where("id", id).first();
  }

  /**
   * FindById User Details
   * @param {number} id
   * @returns
   */
  async findByUserDetails(id) {
    return await knex("user_details")
      .where({
        userId: id,
      })
      .first();
  }

  /**
   * Country Id Wise Get Details
   * @param {number} id
   * @returns
   */
  async countryById(id) {
    return await knex("countries")
      .where({
        id,
      })
      .first();
  }

  /**
   * State Id Wise Get Details
   * @param {number} id
   * @returns
   */
  async stateById(id) {
    return await knex("states")
      .where({
        id,
      })
      .first();
  }

  async stateNameWise(name) {
    let states = await knex("states").where("name", "like", `%${name}`).first();

    if (states) {
      let country = await knex("countries")
        .where("code", states.countryCode)
        .first();

      return { stateId: states.id, countryId: country.id };
    }
    return { stateId: 0, countryId: 0 };
  }

  /**
   * Account Type Wise Get Details
   * @param {number} id
   * @returns
   */
  async accountTypeById(id) {
    return await knex("account_type")
      .where({
        id,
      })
      .first();
  }
  /**
   * Account Type Wise Get Details
   * @param {number} id
   * @returns
   */
  async merchantCategory(id) {
    return await knex("merchant_category")
      .where({
        mcc: id,
      })
      .first();
  }

  /**
   * Account Type Wise Get Details
   * @param {number} id
   * @returns
   */
  async businessAboard(ids) {
    const array = ids.split(",");
    return await knex("business_aboard").whereIn("id", array);
  }

  /**
   * Business Confirmation
   * @param {number} id
   * @returns
   */
  async businessConfirmation(ids) {
    const array = ids.split(",");
    return await knex("business_confirmation").whereIn("id", array);
  }

  /**
   * Account Type Wise Get Details
   * @param {number} id
   * @returns
   */
  async businessTrade(id) {
    return await knex("business_trade").where("id", id).first();
  }

  /**
   * Stripe File upload
   * @param {*} file
   * @param {*} fileName
   * @param {*} mimetype
   * @returns
   */
  async stripeUploadFile(headers, file, fileName, mimetype) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    const stripe = new Stripe(`${key}`);

    return await stripe.files.create({
      purpose: "identity_document",
      file: {
        data: file,
        name: fileName,
        type: mimetype,
      },
    });
  }

  /**
   * Update User Details
   * @param {string} email
   * @param {string} phone
   * @returns
   */
  async userUpdate(headers, body, files, authUser) {
    delete body.confirmAccountNumber;

    try {
      const user = await this.findByUserDetails(authUser.id);
      const details = await this.updateFieldsDetails(
        headers,
        body,
        user,
        files
      );
      delete details.averageValuePerTransaction;

      await knex("user_details")
        .where("userId", authUser.id)
        .update(details)
        .then((result) => {})
        .catch((err) => {
          console.log(err);
        });

      await this.connectAccount(headers, details, files, authUser);

      return await this.findByUserDetails(authUser.id);
    } catch (error) {}
  }

  /**
   * Update user filed details check
   * @param {*} body
   * @param {*} user
   * @param {*} files
   * @returns
   */
  async updateFieldsDetails(headers, body, user, files) {
    body.country = body.country ? body.country : user.country;
    body.state = body.state ? body.state : user.state;

    if (body.businessState) {
      let businessState = await this.stateNameWise(body.businessState);

      body.businessCountry = businessState
        ? businessState.countryId
        : user.businessCountry;
      body.businessState = businessState
        ? businessState.stateId
        : user.businessState;
    } else {
      body.businessCountry = user.businessCountry ? user.businessCountry : null;
      body.businessState = user.businessState ? user.stateId : null;
    }

    body.countryOfBusiness = body.countryOfBusiness
      ? body.countryOfBusiness
      : user.countryOfBusiness;
    body.currency = body.currency ? body.currency : user.currency;
    body.accountTypeId = body.accountTypeId
      ? body.accountTypeId
      : user.accountTypeId;
    body.businessName = body.businessName
      ? body.businessName
      : user.businessName;
    body.firstName = body.firstName ? body.firstName : user.firstName;
    body.maidenName = body.maidenName ? body.maidenName : user.maidenName;
    body.lastName = body.lastName ? body.lastName : user.lastName;
    body.email = body.email ? body.email : user.email;
    body.dateOfBirth = body.dateOfBirth ? body.dateOfBirth : user.dateOfBirth;
    body.personalIDNumber = body.personalIDNumber
      ? body.personalIDNumber
      : user.personalIDNumber;
    body.address = body.address ? body.address : user.address;

    body.city = body.city ? body.city : user.city;
    body.postalCode = body.postalCode ? body.postalCode : user.postalCode;
    body.accountHolderName = body.accountHolderName
      ? body.accountHolderName
      : user.accountHolderName;
    body.sortCode = body.sortCode ? body.sortCode : user.sortCode;
    body.accountNumber = body.accountNumber
      ? body.accountNumber
      : user.accountNumber;
    body.confirmAccountNumber = body.confirmAccountNumber
      ? body.confirmAccountNumber
      : user.confirmAccountNumber;
    body.businessRegistrationNumber = body.businessRegistrationNumber
      ? body.businessRegistrationNumber
      : user.businessRegistrationNumber;
    body.businessCategory = body.businessCategory
      ? body.businessCategory
      : user.businessCategory;
    body.websiteLink = body.websiteLink ? body.websiteLink : user.websiteLink;
    body.VATNumber = body.VATNumber ? body.VATNumber : user.VATNumber;
    body.businessAddress = body.businessAddress
      ? body.businessAddress
      : user.businessAddress;

    body.businessCity = body.businessCity
      ? body.businessCity
      : user.businessCity;
    body.businessPostalCode = body.businessPostalCode
      ? body.businessPostalCode
      : user.businessPostalCode;
    body.monthlySalesVolume = body.monthlySalesVolume
      ? body.monthlySalesVolume
      : user.monthlySalesVolume;
    body.numberOfTransactionPerMonth = body.numberOfTransactionPerMonth
      ? body.numberOfTransactionPerMonth
      : user.numberOfTransactionPerMonth;
    body.maximumSingleTransaction = body.averageValuePerTransaction
      ? body.averageValuePerTransaction
      : user.maximumSingleTransaction;
    body.businessRole = body.businessRole
      ? body.businessRole
      : user.businessRole;
    body.ownerFullName = body.ownerFullName
      ? body.ownerFullName
      : user.ownerFullName;
    body.ownerEmail = body.ownerEmail ? body.ownerEmail : user.ownerEmail;
    body.ownerPersonalID = body.ownerPersonalID
      ? body.ownerPersonalID
      : user.ownerPersonalID;
    body.stripePersonId = body.stripePersonId
      ? body.stripePersonId
      : user.stripePersonId;
    body.businessAboardIds = body.businessAboardIds
      ? body.businessAboardIds
      : user.businessAboardIds;
    body.businessConfirmationIds = body.businessConfirmationIds
      ? body.businessConfirmationIds
      : user.businessConfirmationIds;
    body.businessTrade = body.businessTrade
      ? body.businessTrade
      : user.businessTrade;

    if (files && files.uploadPersonalIDFrontSideImage) {
      let frontImagePath = await uploadFile(
        "identity-document",
        files.uploadPersonalIDFrontSideImage
      );
      const fp = await fs.readFileSync(`${STORAGE_PATH}/${frontImagePath}`);

      let frontImage = await this.stripeUploadFile(
        headers,
        fp,
        files.uploadPersonalIDFrontSideImage.originalname,
        files.uploadPersonalIDFrontSideImage.mimetype
      );

      body.stripeFrontImage = frontImage.id;
      body.uploadPersonalIDFrontSideImage = frontImagePath;
    } else {
      body.stripeFrontImage = user.stripeFrontImage;
      body.uploadPersonalIDFrontSideImage = user.uploadPersonalIDFrontSideImage;
    }

    if (files && files.uploadPersonalIDBackSideImage) {
      let backImagePath = await uploadFile(
        "identity-document",
        files.uploadPersonalIDBackSideImage
      );
      const fp = await fs.readFileSync(`${STORAGE_PATH}/${backImagePath}`);

      let backImage = await this.stripeUploadFile(
        headers,
        fp,
        files.uploadPersonalIDBackSideImage.originalname,
        files.uploadPersonalIDBackSideImage.mimetype
      );

      body.stripeBackImage = backImage.id;
      body.uploadPersonalIDBackSideImage = backImagePath;
    } else {
      body.stripeBackImage = user.stripeBackImage;
      body.uploadPersonalIDBackSideImage = user.uploadPersonalIDBackSideImage;
    }

    if (files && files.ownerSignature) {
      let filePath = await uploadFile(
        "identity-document",
        files.ownerSignature
      );
      const fp = await fs.readFileSync(`${STORAGE_PATH}/${filePath}`);
      let file = await this.stripeUploadFile(
        headers,
        fp,
        files.ownerSignature.originalname,
        files.ownerSignature.mimetype
      );

      body.ownerSignature = filePath;
      body.ownerStripeSignature = file.id;
    } else {
      body.ownerStripeSignature = user.ownerStripeSignature;
      body.ownerSignature = user.ownerSignature;
    }

    if (files && files.ownerFrontImage) {
      let filePath = await uploadFile(
        "identity-document",
        files.ownerFrontImage
      );
      const fp = await fs.readFileSync(`${STORAGE_PATH}/${filePath}`);

      let file = await this.stripeUploadFile(
        headers,
        fp,
        files.ownerFrontImage.originalname,
        files.ownerFrontImage.mimetype
      );

      body.ownerFrontImage = filePath;
      body.ownerStripeFrontId = file.id;
    } else {
      body.ownerStripeFrontId = user.ownerStripeFrontId;
      body.ownerFrontImage = user.ownerFrontImage;
    }

    if (files && files.ownerBackImage) {
      let filePath = await uploadFile(
        "identity-document",
        files.ownerBackImage
      );
      const fp = await fs.readFileSync(`${STORAGE_PATH}/${filePath}`);
      let file = await this.stripeUploadFile(
        headers,
        fp,
        files.ownerBackImage.originalname,
        files.ownerBackImage.mimetype
      );

      body.ownerBackImage = filePath;
      body.ownerStripeBackId = file.id;
    } else {
      body.ownerStripeBackId = user.ownerStripeBackId;
      body.ownerBackImage = user.ownerBackImage;
    }

    return body;
  }

  /**
   *  Create new and update Connect Account
   * @param {object} body
   * @param {object} files
   * @param {object} authUser
   * @returns
   */
  async connectAccount(headers, body, files, authUser) {
    if (body.country) {
      let country = await this.countryById(body.country);
      if (country) {
        body.country = country.code;
      }
    }
    if (body.state) {
      let state = await this.stateById(body.state);
      if (state) {
        body.state = state.name;
      }
    }

    if (body.businessCountry) {
      let country = await this.countryById(body.businessCountry);
      if (country) {
        body.businessCountry = country.code;
      }
    }
    if (body.businessState) {
      let state = await this.stateById(body.businessState);
      if (state) {
        body.businessState = state.name;
      }
    }

    if (body.accountTypeId) {
      let accountType = await this.accountTypeById(body.accountTypeId);
      if (accountType) {
        body.businessType = accountType.accountType;
      }
    }
    let userDetails = await this.findByUserDetails(authUser.id);

    try {
      // Create new stripe
      if (!userDetails.stripeConnectAccountId) {
        if (body.countryOfBusiness && body.currency && body.businessType) {
          let connect = await this.createAc(headers, body, authUser);

          if (connect) {
            await knex("user_details")
              .update({ stripeConnectAccountId: connect.id })
              .where("userId", authUser.id);
          }
        }
      } else {
        // Update stripe
        userDetails = await this.findByUserDetails(authUser.id);
        body.countryCode = authUser.countryCode;
        body.phone = authUser.phone;
        body.email = authUser.email;

        if (body.businessType == "individual") {
          if (
            !userDetails.accountHolderName &&
            !userDetails.sortCode &&
            !userDetails.accountNumber
          ) {
            await this.updateIndividualAc(headers, body, userDetails);
          }
        }
        if (body.businessType == "company") {
          // if (
          //   !userDetails.accountHolderName &&
          //   !userDetails.sortCode &&
          //   !userDetails.accountNumber
          // ) {
          await this.updateConnectAccountOnStripe(headers, body, userDetails);
          // }
        }
      }
      userDetails = await this.findByUserDetails(authUser.id);

      if (
        userDetails.accountHolderName &&
        userDetails.sortCode &&
        userDetails.accountNumber
      ) {
        await this.addOrUpdateBankAccount(headers, body, userDetails);
      }

      return {
        status: true,
      };
    } catch (err) {
      console.log("=====connectAccount-=====");
      console.log(error);
      console.log("=====connectAccount-=====");
      return {
        status: false,
        message: err.message,
      };
    }
  }

  /**
   * Create Stripe Account ( Company  )
   * @param {*} body
   * @param {*} authUser
   * @returns
   */
  async createAc(headers, body, authUser) {
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    console.log(key);

    const stripe = new Stripe(`${key}`);

    try {
      return await stripe.accounts.create({
        type: "custom",
        country: body.countryOfBusiness,
        default_currency: body.currency,
        email: authUser.email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_type: body.businessType,
        tos_acceptance: {
          date: Math.floor(Date.now() / 1000),
          ip: "222.145.142.231",
        },
      });
    } catch (error) {
      console.log("=====createAc-=====");
      console.log(error);
      console.log("=====createAc-=====");
    }
  }

  /**
   * Update Individual AC
   * @param {*} body
   * @param {*} userDetails
   * @returns
   */
  async updateIndividualAc(headers, body, userDetails) {
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    // console.log(key);
    const stripe = new Stripe(`${key}`);

    let birthdateArray;
    const birtdate = body.dateOfBirth
      ? moment(body.dateOfBirth).format("YYYY-MM-DD").split("-")
      : null;

    if (birtdate) {
      birthdateArray = {
        dob: {
          day: birtdate[2],
          month: birtdate[1],
          year: birtdate[0],
        },
      };
    }

    return await stripe.accounts.update(userDetails.stripeConnectAccountId, {
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
      business_type: body.businessType,
      business_profile: {
        url: body.websiteLink,
        mcc: body.businessCategory,
      },
      individual: {
        first_name: body.firstName,
        last_name: body.lastName,
        email: body.email,
        ...birthdateArray,
        address: {
          city: body.city,
          country: body.country,
          line1: body.address,
          line2: "",
          postal_code: body.postalCode,
          state: body.state,
        },
        metadata: {
          country_code: body.countryCode,
        },
        phone: body.phone,
        verification: {
          document: {
            back: body.stripeFrontImage,
            front: body.stripeBackImage,
          },
        },
      },
    });
  }

  /**
   * Create customer
   * @param {*} body
   * @param {*} authUser
   * @returns
   */
  async createPerson(headers, body, authUser) {
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    // console.log(key);
    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    let birthdateArray;
    const birtdate = body.dateOfBirth
      ? moment(body.dateOfBirth).format("YYYY-MM-DD").split("-")
      : null;

    if (birtdate) {
      birthdateArray = {
        dob: {
          day: birtdate[2],
          month: birtdate[1],
          year: birtdate[0],
        },
      };
    }

    try {
      let account = await stripe.accounts.createPerson(
        authUser.stripeConnectAccountId,
        {
          ...birthdateArray,
          first_name: body.firstName,
          maiden_name: body.maidenName,
          last_name: body.lastName,
          email: body.email,
          phone: body.countryCode + "" + body.phone,
        }
      );

      await knex("user_details")
        .update({ stripePersonId: account.id })
        .where("userId", authUser.userId);

      return account;
    } catch (error) {
      console.log("=====createAc-=====");
      console.log(error);
      console.log("=====createAc-=====");

      return {
        status: false,
        message: error.message,
      };
    }
  }

  /**
   * Update customer
   * @param {*} body
   * @param {*} authUser
   * @returns
   */
  async updatePerson(headers, body, authUser) {
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    console.log("=========createPerson===============");
    console.log(authUser);
    console.log("=========createPerson===============");

    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    // console.log(key);
    const stripe = new Stripe(`${key}`);

    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    const person = await stripe.accounts.retrievePerson(
      authUser.stripeConnectAccountId,
      body.stripePersonId
    );

    console.log("=========retrievePerson===============");
    console.log(person);
    console.log(person.verification.document.back);
    console.log(person.verification.document.front);
    console.log("=========retrievePerson===============");

    let relationship, verification;
    let title;
    if (body.businessRole) {
      if (body.businessRole == "owner") {
        relationship = {
          relationship: {
            owner: true,
            title: "CEO",
            representative: true,
          },
        };

        if (person) {
          if (
            !person.verification.document.back &&
            !person.verification.document.front
          ) {
            verification = {
              verification: {
                document: {
                  back: body.stripeFrontImage,
                  front: body.stripeBackImage,
                },
              },
            };
          }
        }
      }
      if (body.businessRole == "representative") {
        relationship = {
          relationship: {
            executive: true,
            s: true,
            title: "representative",
          },
        };

        if (person) {
          if (
            !person.verification.document.back &&
            !person.verification.document.front
          ) {
            verification = {
              verification: {
                document: {
                  back: body.ownerStripeFrontId,
                  front: body.ownerStripeBackId,
                },
              },
            };
          }
        }
      }
    }

    let birthdateArray;
    const birtdate = body.dateOfBirth
      ? moment(body.dateOfBirth).format("YYYY-MM-DD").split("-")
      : null;

    if (birtdate) {
      birthdateArray = {
        dob: {
          day: birtdate[2],
          month: birtdate[1],
          year: birtdate[0],
        },
      };
    }

    console.log("============================");
    console.log(
      (authUser.stripeConnectAccountId,
      body.stripePersonId,
      {
        address: {
          city: body.city,
          country: body.country,
          line1: body.address,
          line2: "",
          postal_code: body.postalCode,
          state: body.state,
        },
        ...birthdateArray,
        first_name: body.firstName,
        maiden_name: body.maidenName,
        last_name: body.lastName,
        id_number: body.personalIDNumber,
        email: body.email,
        title: title,
        phone: body.countryCode + "" + body.phone,
        ...relationship,
        ...verification,
      })
    );
    console.log("============================");

    try {
      return await stripe.accounts.updatePerson(
        authUser.stripeConnectAccountId,
        body.stripePersonId,
        {
          address: {
            city: body.city,
            country: body.country,
            line1: body.address,
            line2: "",
            postal_code: body.postalCode,
            state: body.state,
          },
          ...birthdateArray,
          first_name: body.firstName,
          maiden_name: body.maidenName,
          last_name: body.lastName,
          id_number: body.personalIDNumber,
          email: body.email,
          title: title,
          phone: body.countryCode + "" + body.phone,
          ...relationship,
          ...verification,
        }
      );
    } catch (error) {
      console.log("=========updatePerson===============");
      console.log(error);
      console.log("=========updatePerson===============");

      // console.log(error);

      return {
        status: false,
        message: error.message,
      };
    }
  }

  /**
   * Update company details
   * @param {object} body
   * @param {object} authUser
   * @returns
   */
  async updateConnectAccountOnStripe(headers, body, authUser) {
    console.log("===============body===============");
    console.log(body);
    console.log("===============body===============");

    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    // console.log(key);
    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    const frontIdentity = body.stripeFrontImage;
    const backIdentity = body.stripeBackImage;

    console.log(body.stripePersonId);
    if (body.stripePersonId) {
      await this.updatePerson(headers, body, authUser);
    } else {
      if (body.firstName && body.lastName && body.email && body.dateOfBirth) {
        await this.createPerson(headers, body, authUser);
      }
    }

    console.log(
      "============updateConnectAccountOnStripe======================="
    );

    console.log({
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
      business_type: body.businessType,
      business_profile: {
        url: body.websiteLink,
        mcc: body.businessCategory,
        name: body.businessName,
        support_address: {
          city: body.businessCity,
          country: body.businessCountry,
          line1: body.businessAddress,
          line2: "",
          postal_code: body.businessPostalCode,
          state: body.businessState,
        },
        support_phone: body.countryCode + "" + body.phone,
        support_email: body.email,
      },
      company: {
        ownership_declaration: {
          date: Math.floor(Date.now() / 1000),
          ip: "222.145.142.231",
        },
        address: {
          city: body.businessCity,
          country: body.businessCountry,
          line1: body.businessAddress,
          line2: "",
          postal_code: body.businessPostalCode,
          state: body.businessState,
        },
        directors_provided: true,
        executives_provided: true,
        verification: {
          document: {
            front: frontIdentity,
            back: backIdentity,
          },
        },
        owners_provided: true,
        name: body.businessName,
        vat_id: body.VATNumber,
        phone: body.countryCode + "" + body.phone,
        tax_id: body.businessRegistrationNumber,
      },
      tos_acceptance: {
        date: Math.floor(Date.now() / 1000),
        ip: "222.145.142.231",
      },
      settings: {
        payouts: {
          schedule: {
            delay_days: 7,
            interval: "daily",
          },
        },
      },
    });

    console.log(
      "============updateConnectAccountOnStripe======================="
    );

    try {
      return await stripe.accounts.update(authUser.stripeConnectAccountId, {
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_type: body.businessType,
        business_profile: {
          url: body.websiteLink,
          mcc: body.businessCategory,
          name: body.businessName,
          support_address: {
            city: body.businessCity,
            country: body.businessCountry,
            line1: body.businessAddress,
            line2: "",
            postal_code: body.businessPostalCode,
            state: body.businessState,
          },
          support_phone: body.countryCode + "" + body.phone,
          support_email: body.email,
        },
        company: {
          ownership_declaration: {
            date: Math.floor(Date.now() / 1000),
            ip: "222.145.142.231",
          },
          address: {
            city: body.businessCity,
            country: body.businessCountry,
            line1: body.businessAddress,
            line2: "",
            postal_code: body.businessPostalCode,
            state: body.businessState,
          },
          directors_provided: true,
          executives_provided: true,
          verification: {
            document: {
              front: frontIdentity,
              back: backIdentity,
            },
          },
          owners_provided: true,
          name: body.businessName,
          vat_id: body.VATNumber,
          phone: body.countryCode + "" + body.phone,
          tax_id: body.businessRegistrationNumber,
        },
        tos_acceptance: {
          date: Math.floor(Date.now() / 1000),
          ip: "222.145.142.231",
        },
        settings: {
          payouts: {
            schedule: {
              delay_days: 7,
              interval: "daily",
            },
          },
        },
      });
    } catch (error) {
      console.log("=========updateConnectAccountOnStripe===============");
      console.log(error);
      console.log("=========updateConnectAccountOnStripe===============");

      // console.log(error.message);
    }
  }

  /**
   *  Add Or Update Connect Account Stripe
   * @param {object} body
   * @param {object} authUser
   * @returns
   */
  async addOrUpdateBankAccount(headers, body, user) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    // console.log(key);
    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    return await stripe.accounts.update(user.stripeConnectAccountId, {
      external_account: {
        object: "bank_account",
        country: body.country,
        currency: body.currency,
        account_holder_name: body.accountHolderName,
        account_holder_type: body.businessType,
        routing_number: body.sortCode,
        account_number: body.accountNumber,
      },
    });
  }

  /**
   * Get Profile Details
   * @param {*} authUser
   * @returns
   */
  async getProfile(headers, authUser) {
    let key =
      headers.stripemode == "staging"
        ? process.env.STRIPE_KEY
        : process.env.STRIPE_PRODUCTION_KEY;

    const stripe = new Stripe(`${key}`);
    // const stripe = new Stripe(`${process.env.STRIPE_KEY}`);

    let userDetails = await this.findByUserDetails(authUser.id);
    if (userDetails.ownerFrontImage) {
      userDetails.ownerFrontImage = `${process.env.APP_URL}/storage/${userDetails.ownerFrontImage}`;
    }
    if (userDetails.ownerBackImage) {
      userDetails.ownerBackImage = `${process.env.APP_URL}/storage/${userDetails.ownerBackImage}`;
    }
    if (userDetails.ownerSignature) {
      userDetails.ownerSignature = `${process.env.APP_URL}/storage/${userDetails.ownerSignature}`;
    }
    if (userDetails.uploadPersonalIDFrontSideImage) {
      userDetails.uploadPersonalIDFrontSideImage = `${process.env.APP_URL}/storage/${userDetails.uploadPersonalIDFrontSideImage}`;
    }
    if (userDetails.uploadPersonalIDBackSideImage) {
      userDetails.uploadPersonalIDBackSideImage = `${process.env.APP_URL}/storage/${userDetails.uploadPersonalIDBackSideImage}`;
    }

    userDetails.personalEmail = userDetails.email;

    // Bank Details

    userDetails.sortCode = userDetails.sortCode
      ? userDetails.sortCode.replace(/.(?=.{0})/g, "*")
      : null;
    userDetails.accountNumber = userDetails.accountNumber
      ? userDetails.accountNumber.replace(/.(?=.{4})/g, "*")
      : null;

    userDetails.averageValuePerTransaction = Number(
      userDetails.maximumSingleTransaction
    );

    userDetails.dateOfBirth = userDetails.dateOfBirth
      ? moment(userDetails.dateOfBirth).unix()
      : null;

    if (userDetails.country) {
      let country = await this.countryById(userDetails.country);
      if (country) {
        userDetails.country = country;
      }
    }
    if (userDetails.countryOfBusiness) {
      let country = await knex("countries")
        .where("code", userDetails.countryOfBusiness)
        .first();
      if (country) {
        userDetails.countryOfBusiness = country;
      }
    }

    if (userDetails.state) {
      let state = await this.stateById(userDetails.state);
      if (state) {
        userDetails.state = state;
      }
    }

    if (userDetails.businessCountry) {
      let country = await this.countryById(userDetails.businessCountry);
      if (country) {
        userDetails.businessCountry = country;
      }
    }
    if (userDetails.businessState) {
      let state = await this.stateById(userDetails.businessState);
      if (state) {
        userDetails.businessState = state;
      }
    }

    if (userDetails.accountTypeId) {
      let accountType = await this.accountTypeById(userDetails.accountTypeId);
      if (accountType) {
        userDetails.accountType = accountType;
      }
    }

    if (userDetails.businessCategory) {
      let accountType = await this.merchantCategory(
        userDetails.businessCategory
      );
      if (accountType) {
        userDetails.businessCategory = accountType;
      }
    }

    if (userDetails.businessAboardIds) {
      let businessAboard = await this.businessAboard(
        userDetails.businessAboardIds
      );
      if (businessAboard) {
        userDetails.businessAboard = businessAboard;
      }
    }

    if (userDetails.businessConfirmationIds) {
      let businessConfirmation = await this.businessConfirmation(
        userDetails.businessConfirmationIds
      );
      if (businessConfirmation) {
        const bcm = await Promise.all(
          await businessConfirmation.map(async (data) => {
            return {
              id: data.id,
              description: data.description,
              highlightText: data.highlightText,
              restrictedTitle: data.restrictedTitle,
              restrictedDescription: data.restrictedDescription,
              restrictedDetails: data.restrictedDetails
                ? data.restrictedDetails.split(",")
                : null,
            };
          })
        );

        userDetails.businessConfirmation = bcm;
      }
    }

    if (userDetails.businessTrade && userDetails.businessTrade != 0) {
      const trade = eval("(" + userDetails.businessTrade + ")");

      const bt = await Promise.all(
        await trade.map(async (data) => {
          let businessTrade = await this.businessTrade(data.id);
          delete businessTrade.createdAt;
          delete businessTrade.updatedAt;
          return {
            ...businessTrade,
            registerNumber: data.registerNumber,
          };
        })
      );
      userDetails.businessTrade = bt;
    } else {
      userDetails.businessTrade = null;
    }

    userDetails.isVerified = false;
    userDetails.stripeStatus = "pending";

    if (userDetails.stripeConnectAccountId) {
      let connectAccount = await stripe.account.retrieve(
        userDetails.stripeConnectAccountId,
        {}
      );
      userDetails.stripeErrorMessage = connectAccount.requirements.errors;
      if (
        connectAccount.payouts_enabled == true &&
        connectAccount.charges_enabled == true &&
        connectAccount.capabilities.transfers == "active"
      ) {
        userDetails.isVerified = true;
        userDetails.stripeStatus = "complete";
        userDetails.stripeErrorMessage = {};
      }
    }

    userDetails.isPersonalDetails = false;
    if (
      (userDetails.dateOfBirth,
      userDetails.uploadPersonalIDFrontSideImage,
      userDetails.uploadPersonalIDBackSideImage)
    ) {
      userDetails.isPersonalDetails = true;
    }

    userDetails.isBankDetails = false;
    if (
      userDetails.accountHolderName &&
      userDetails.sortCode &&
      userDetails.accountNumber
    ) {
      userDetails.isBankDetails = true;
    }

    userDetails.isBusinessDetails = false;
    if (
      (userDetails.websiteLink,
      userDetails.businessCategory,
      userDetails.businessRegistrationNumber,
      userDetails.businessPostalCode)
    ) {
      userDetails.isBusinessDetails = true;
    }
    userDetails.isDirectorDetails = false;
    if (
      (userDetails.ownerPersonalID,
      userDetails.ownerFrontImage,
      userDetails.ownerBackImage,
      userDetails.ownerEmail)
    ) {
      userDetails.isDirectorDetails = true;
    }

    if (headers.stripemode == "staging") {
      userDetails.UKLocationsId = "tml_FJjz9AvTqi7ANA";
      userDetails.USLocationsId = "tml_FJjzzQa4j5L6hF";
    } else {
      userDetails.UKLocationsId = "tml_FFLhogOcmeqXm9";
      userDetails.USLocationsId = "tml_FEgQhQxmtvsoWq";
    }

    delete userDetails.maximumSingleTransaction;
    delete userDetails.id;
    delete userDetails.createdAt;
    delete userDetails.updatedAt;
    return userDetails;
  }
}
export default new UserServices();
