import UserServices from "./user.service";
import otpVerificationService from "../otp-verification/otp-verification.service";
// import UserResource from "../auth/resource/user.resource";
import UserResource from "../../resource/user.resource";
import { encodeString, storeAsSync } from "../../common/helper/common.helper";

class UserController {
  /**
   * Update profile
   * @param {object} req
   * @param {object} res
   */
  async updateProfile(req, res) {
    console.log(req.headers);
    const data = await UserServices.userUpdate(
      req.headers,
      req.body,
      req.files,
      req.user
    );

    const user = await UserServices.findById(req.user.id);
    const getProfile = await UserServices.getProfile(req.headers, req.user);

    return res.json({
      data: {
        ...new UserResource(user),
        ...getProfile,
      },
    });
  }

  /**
   * Get profile
   * @param {object} req
   * @param {object} res
   */
  async getProfile(req, res) {
    const user = await UserServices.findById(req.user.id);
    const getProfile = await UserServices.getProfile(req.headers, req.user);
    const deleteAccountUrl = `${
      process.env.APP_URL
    }/delete-account?token=${encodeString(user.id.toString())}&email=${
      user.email
    }`;

    return res.json({
      data: {
        ...new UserResource(user),
        ...getProfile,
        deleteAccountUrl,
      },
    });
  }
}
export default new UserController();
