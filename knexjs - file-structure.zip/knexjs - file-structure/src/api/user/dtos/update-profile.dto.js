import Joi from "joi";

export default Joi.object({
  countryOfBusiness: Joi.optional().messages({
    "string.empty": "The country of business field is optional.",
  }),
  currency: Joi.optional().messages({
    "string.empty": "The currency field is optional.",
  }),
  accountTypeId: Joi.optional().messages({
    "string.empty": "The account type  field is optional.",
  }),
  businessName: Joi.optional().messages({
    "string.empty": "The business name field is optional.",
  }),
  firstName: Joi.optional().messages({
    "string.empty": "The first name field is optional.",
  }),
  maidenName: Joi.optional().messages({
    "string.empty": "The maiden name field is optional.",
  }),
  lastName: Joi.optional().messages({
    "string.empty": "The last name field is optional.",
  }),
  email: Joi.optional().messages({
    "string.empty": "The email field is optional.",
  }),
  dateOfBirth: Joi.optional().messages({
    "string.empty": "The date of birth field is optional.",
  }),
  personalIDNumber: Joi.optional().messages({
    "string.empty": "The personal ID number field is optional.",
  }),
  uploadPersonalIDFrontSideImage: Joi.optional().messages({
    "string.empty":
      "The upload personal ID front side image field is optional.",
  }),
  uploadPersonalIDBackSideImage: Joi.optional().messages({
    "string.empty": "The upload personal ID back side image field is optional.",
  }),
  address: Joi.optional().messages({
    "string.empty": "The address field is optional.",
  }),
  country: Joi.optional().messages({
    "string.empty": "The country field is optional.",
  }),
  state: Joi.optional().messages({
    "string.empty": "The state field is optional.",
  }),
  city: Joi.optional().messages({
    "string.empty": "The city field is optional.",
  }),
  postalCode: Joi.optional().messages({
    "string.empty": "The postal code field is optional.",
  }),
  accountHolderName: Joi.optional().messages({
    "string.empty": "The account holder name field is optional.",
  }),
  sortCode: Joi.optional().messages({
    "string.empty": "The sort code field is optional.",
  }),
  accountNumber: Joi.optional().messages({
    "string.empty": "The account number field is optional.",
  }),
  confirmAccountNumber: Joi.optional().messages({
    "string.empty": "The confirm account number field is optional.",
  }),
  businessRegistrationNumber: Joi.optional().messages({
    "string.empty": "The business registration number field is optional.",
  }),
  businessCategory: Joi.optional().messages({
    "string.empty": "The business category field is optional.",
  }),
  websiteLink: Joi.optional().messages({
    "string.empty": "The website link field is optional.",
  }),
  VATNumber: Joi.optional().messages({
    "string.empty": "The VAT number field is optional.",
  }),
  businessAddress: Joi.optional().messages({
    "string.empty": "The business address field is optional.",
  }),
  businessCountry: Joi.optional().messages({
    "string.empty": "The business country field is optional.",
  }),
  businessState: Joi.optional().messages({
    "string.empty": "The business state field is optional.",
  }),
  businessCity: Joi.optional().messages({
    "string.empty": "The business city field is optional.",
  }),
  businessPostalCode: Joi.optional().messages({
    "string.empty": "The business postal code field is optional.",
  }),
  monthlySalesVolume: Joi.optional().messages({
    "string.empty": "The monthly sales volume field is optional.",
  }),
  numberOfTransactionPerMonth: Joi.optional().messages({
    "string.empty": "The number of transaction per month field is optional.",
  }),
  // maximumSingleTransaction: Joi.optional().messages({
  //   "string.empty": "The maximum single transaction field is optional.",
  // }),
  averageValuePerTransaction: Joi.optional().messages({
    "string.empty": "The average transaction field is optional.",
  }),
  businessAboardIds: Joi.optional().messages({
    "string.empty": "The business aboard  field is optional.",
  }),
  businessConfirmationIds: Joi.optional().messages({
    "string.empty": "The business confirmation Ids field is optional.",
  }),
  businessTrade: Joi.optional().messages({
    "string.empty": "The business trade field is optional.",
  }),
  businessRole: Joi.optional().messages({
    "string.empty": "The business role field is optional.",
  }),
  ownerFullName: Joi.optional().messages({
    "string.empty": "The owner full name field is optional.",
  }),
  ownerEmail: Joi.optional().messages({
    "string.empty": "The owner email field is optional.",
  }),
  ownerSignature: Joi.optional().messages({
    "string.empty": "The owner signature field is optional.",
  }),
  ownerPersonalID: Joi.optional().messages({
    "string.empty": "The owner personal field is optional.",
  }),
  ownerFrontImage: Joi.optional().messages({
    "string.empty": "The owner front image is optional.",
  }),
  ownerBackImage: Joi.optional().messages({
    "string.empty": "The owner back image field is optional.",
  }),
});
