import { Router } from "express";
import updateProfileDto from "./dtos/update-profile.dto";
import expressAsyncHandler from "express-async-handler";
import validator from "../../common/config/validator.config";
import UserController from "./user.controller";
import authenticateMiddleware from "../../common/middleware/authenticate.middleware";

const router = Router();

router.post(
  "/update-profile",
  authenticateMiddleware,
  validator.body(updateProfileDto),
  expressAsyncHandler(UserController.updateProfile)
);
router.get(
  "/profile",
  authenticateMiddleware,
  expressAsyncHandler(UserController.getProfile)
);

export default router;
