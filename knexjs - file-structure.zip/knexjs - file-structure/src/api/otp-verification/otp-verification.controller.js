import otpVerificationService from "./otp-verification.service";
import authService from "../auth/auth.service";
import UserResource from "../../resource/user.resource";
import UserServices from "../user/user.service";

class OtpVerificationController {
  /**
   * Verify Otp
   * @param {object} req
   * @param {object} res
   */
  async verify(req, res) {
    const user = await otpVerificationService.verify(req.body);
    const getProfile = await UserServices.getProfile(req.headers, user);
    const authentication = await authService.generateTokenPairs(
      user.id,
      user.email
    );
    return res.json({
      data: {
        ...new UserResource(user),
        ...getProfile,
        authentication,
      },
    });
  }

  /**
   * Resend Otp
   * @param {object} req
   * @param {object} res
   */
  async resendOtp(req, res) {
    await otpVerificationService.resendOtp(req.body);

    let message;
    if (req.body.email) {
      message = "Please check otp send on your email address.";
    } else {
      message = "Please check otp send on your phone number.";
    }
    return res.send({
      message: message,
    });
  }
}
export default new OtpVerificationController();
