import Joi from "joi";

const schema = Joi.object({
  email: Joi.string().email().optional().messages({
    "string.empty": "The email field is optional.",
    "string.email": "The email must be a valid email.",
  }),
  countryCode: Joi.string().optional().messages({
    "string.empty": "The country code field is optional.",
  }),
  phone: Joi.string().optional().messages({
    "string.empty": "The phone number field is optional.",
  }),
  otp: Joi.number().required(),
});

export default schema;
