import knex from "../../common/config/database.config";
import moment from "moment";
import BadRequestException from "../../common/exceptions/bad-request.exception";
import userService from "../user/user.service";
import sendMail from "../../common/helper/mail.helper";
import sendSms from "../../common/helper/sms.helper";
import NotFoundException from "../../common/exceptions/not-found.exception";

class OtpVerificationService {
  /**
   *
   * @param {object} body
   * @returns
   */
  async verify(body) {
    let user = await userService.findOne(
      body.email,
      body.countryCode,
      body.phone
    );
    if (user) {
      if ((await user.otp) != body.otp) {
        throw new BadRequestException(
          "Incorrect code entered. Please try again!"
        );
      }

      if (Date.now() > user.otpExpiredAt.getTime()) {
        throw new BadRequestException("Otp Expire!");
      }

      user = await userService.createOrUpdate(
        {
          otpVerifiedAt: moment().format("YYYY-MM-DD HH:mm:ss"),
        },
        user.id
      );

      const isAlreadyAdded = await knex("user_details")
        .where("userId", user.id)
        .first();

      if (!isAlreadyAdded) {
        await knex("user_details").insert({
          userId: user.id,
        });
      }
      return { ...user, isLogin: true };
    } else {
      let temporaryUser = await userService.findOneTemporaryUser(
        body.email,
        body.countryCode,
        body.phone
      );
      if (!temporaryUser) {
        throw new BadRequestException("Email or Phone number not register.");
      }
      if ((await temporaryUser.otp) != body.otp) {
        throw new BadRequestException(
          "Incorrect code entered. Please try again!"
        );
      }

      if (Date.now() > temporaryUser.otpExpiredAt.getTime()) {
        throw new BadRequestException("Otp Expire!");
      }
      const user = await userService.createOrUpdate({
        email: temporaryUser.email,
        countryCode: temporaryUser.countryCode,
        phone: temporaryUser.phone,
        otp: temporaryUser.otp,
        otpExpiredAt: temporaryUser.otpExpiredAt,
        otpVerifiedAt: moment().format("YYYY-MM-DD HH:mm:ss"),
      });

      const isAlreadyAdded = await knex("user_details")
        .where("userId", user.id)
        .first();

      if (!isAlreadyAdded) {
        await knex("user_details").insert({
          userId: user.id,
        });
      }
      await knex("temporary_users")
        .where({
          id: temporaryUser.id,
        })
        .delete();

      return { ...user, isLogin: false };
    }
  }
  // async verify(body) {
  //   let user;
  //   if (body.phone) {
  //     user = await userService.findByPhone(body.countryCode, body.phone);
  //   }
  //   if (body.email) {
  //     user = await userService.findByEmail(body.email);
  //   }
  //   if (!user) {
  //     throw new NotFoundException(
  //       body.email
  //         ? "Email is not register with us."
  //         : "phone number is not register with us."
  //     );
  //   }

  // if ((await user.otp) != body.otp) {
  //   throw new BadRequestException("Invalid Otp.");
  // }

  // if (Date.now() > user.otpExpiredAt.getTime()) {
  //   throw new BadRequestException("Otp Expire!");
  // }

  // await userService.createOrUpdate(
  //   {
  //     otpVerifiedAt: moment().format("YYYY-MM-DD HH:mm:ss"),
  //   },
  //   user.id
  // );

  // return await userService.findById(user.id);
  // }

  /**
   * Resend Otp
   * @param {object} body
   */
  async resendOtp(body) {
    let user;
    if (body.email) {
      user = await userService.findByEmail(body.email);
    }
    if (body.phone && body.countryCode) {
      user = await userService.findByPhone(body.countryCode, body.phone);
    }
    if (user) {
      const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
      await userService.createOrUpdate(
        {
          otp,
          otpExpiredAt: await moment()
            .add(2, "minutes")
            .format("YYYY-MM-DD HH:mm:ss"),
        },
        user.id
      );
      body.email
        ? await sendMail({ otp, email: user.email }, "email-verification")
        : await sendSms({ otp, phone: `${user.countryCode}${user.phone}` });
    } else {
      let temporaryUser = body.email
        ? await knex("temporary_users")
            .where({
              email: body.email,
            })
            .first()
        : await knex("temporary_users")
            .where({
              countryCode: body.countryCode,
              phone: body.phone,
            })
            .first();
      if (!temporaryUser) {
        throw new NotFoundException("Email or phone is not register with us.");
      }
      const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
      await userService.createOrUpdateTemporaryUser(
        {
          otp,
          otpExpiredAt: await moment()
            .add(2, "minutes")
            .format("YYYY-MM-DD HH:mm:ss"),
        },
        temporaryUser.id
      );
      body.email
        ? await sendMail(
            { otp, email: temporaryUser.email },
            "email-verification"
          )
        : await sendSms({
            otp,
            phone: `${temporaryUser.countryCode}${temporaryUser.phone}`,
          });
    }
  }
  // async resendOtp(body) {
  //   // const user = await userService.findOne(
  //   //   body.email,
  //   //   body.countryCode,
  //   //   body.phone
  //   // );
  //   // if (!user) {
  //   //   throw new NotFoundException("Email is not register with us.");
  //   // }

  //   let user;
  //   if (body.phone) {
  //     user = await userService.findByPhone(body.countryCode, body.phone);
  //   }
  //   if (body.email) {
  //     user = await userService.findByEmail(body.email);
  //   }

  //   if (!user) {
  //     throw new NotFoundException(
  //       body.email
  //         ? "Email is not register with us."
  //         : "phone number is not register with us."
  //     );
  //   }

  // const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
  // await userService.createOrUpdate(
  //   {
  //     otp,
  //     otpExpiredAt: await moment()
  //       .add(2, "minutes")
  //       .format("YYYY-MM-DD HH:mm:ss"),
  //   },
  //   user.id
  // );

  // body.email
  //   ? await sendMail({ otp, email: user.email }, "email-verification")
  //   : await sendSms({ otp, phone: `${user.countryCode}${user.phone}` });

  //   return;
  // }
}
export default new OtpVerificationService();
