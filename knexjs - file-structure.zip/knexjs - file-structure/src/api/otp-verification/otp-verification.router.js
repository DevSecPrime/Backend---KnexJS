import { Router } from "express";
import otpVerificationController from "./otp-verification.controller";
import validator from "../../common/config/validator.config";
import otpVerifyDto from "./dtos/otp-verify.dto";
import authenticateMiddleware from "../../common/middleware/authenticate.middleware";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router
  .post(
    "/verify",
    // authenticateMiddleware,
    validator.body(otpVerifyDto),
    expressAsyncHandler(otpVerificationController.verify)
  )
  .post(
    "/resend",
    // authenticateMiddleware,
    expressAsyncHandler(otpVerificationController.resendOtp)
  );

export default router;
