import knex from "../../common/config/database.config";
import moment from "moment";
import Stripe from "stripe";
import BadRequestException from "../../common/exceptions/bad-request.exception";

class CountryBusinessServices {
  /**
   * Get Account Type
   * @returns
   */
  async getCountryBusiness() {
    // return await knex("business_aboard");
    const stripe = new Stripe(`${process.env.STRIPE_KEY}`);
    return await stripe.countrySpecs.list({
      limit: 100,
    });
  }
}
export default new CountryBusinessServices();
