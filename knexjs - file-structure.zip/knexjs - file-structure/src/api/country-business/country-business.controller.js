import countryBusinessService from "./country-business.service";
import knex from "../../common/config/database.config";

class CountryBusinessController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getCountryBusiness(req, res) {
    const countryBusinessData =
      await countryBusinessService.getCountryBusiness();

    const data = await Promise.all(
      countryBusinessData.data.map(async (data) => {
        const country = await knex("countries")
          .where({
            code: data.id,
          })
          .first();

        return {
          id: data.id,
          countryName: country?.name,
          supportedPaymentCurrencies: data.supported_payment_currencies,
        };
      })
    );

    return res.send({ data });
  }
}
export default new CountryBusinessController();
