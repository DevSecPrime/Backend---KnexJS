import { Router } from "express";
import countryBusinessController from "./country-business.controller";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router.get(
  "/",
  expressAsyncHandler(countryBusinessController.getCountryBusiness)
);
export default router;
