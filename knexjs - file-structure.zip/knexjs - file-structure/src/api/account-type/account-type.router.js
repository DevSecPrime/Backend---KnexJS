import { Router } from "express";
import accountTypeController from "./account-type.controller";
import expressAsyncHandler from "express-async-handler";

const router = Router();

router.get("/", expressAsyncHandler(accountTypeController.getAccountType));
export default router;
