import accountTypeService from "./account-type.service";

class AccountTypeController {
  /**
   * Get Account Type
   * @param {object} req
   * @param {object} res
   * @returns
   */
  async getAccountType(req, res) {
    const data = await accountTypeService.getAccountType();
    return res.send({ data });
  }
}
export default new AccountTypeController();
