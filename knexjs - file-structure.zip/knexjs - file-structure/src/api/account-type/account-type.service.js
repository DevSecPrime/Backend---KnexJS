import knex from "../../common/config/database.config";
import moment from "moment";
import BadRequestException from "../../common/exceptions/bad-request.exception";

class AccountTypeServices {
  /**
   * Get Account Type
   * @returns
   */
  async getAccountType() {
    return await knex("account_type");
  }
}
export default new AccountTypeServices();
