const { Country } = require("country-state-city");

exports.up = (knex) =>
  knex.schema
    .createTable("countries", (table) => {
      table.increments("id").unsigned().primary();
      table.string("name");
      table.string("code");
      table.string("flag");
      table.string("phonecode");
      table.string("currency");
      table.timestamp("createdAt").defaultTo(knex.fn.now());
      table.timestamp("updatedAt").nullable();
    })
    .then(async () => {
      const countries = await Country.getAllCountries();

      await Promise.all(
        countries.map(async (country) => {
          await knex("countries").insert([
            {
              name: country.name,
              code: country.isoCode,
              // flag: country.flag,
              phonecode: country.phonecode,
              currency: country.currency,
            },
          ]);
        })
      );
    });

exports.down = (knex) => knex.schema.dropTable("countries");
