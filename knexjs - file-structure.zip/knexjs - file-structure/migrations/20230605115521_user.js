exports.up = (knex) =>
  knex.schema.createTable("users", (table) => {
    table.increments("id").unsigned().primary();
    table.string("countryCode").nullable();
    table.string("phone").unique();
    table.string("email", 192).unique().nullable();
    table.string("otp").nullable();
    table.timestamp("otpVerifiedAt").nullable();
    table.timestamp("otpExpiredAt").nullable();
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });

exports.down = (knex) => knex.schema.dropTable("users");
