const IpMessagingBase = require("twilio/lib/rest/IpMessagingBase");

exports.up = (knex) =>
  knex.schema.createTable("merchant_category", (table) => {
    table.increments("id").unsigned().primary();
    table.integer("mcc");
    table.string("name");
    table.string("description");
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });

exports.down = (knex) => knex.schema.dropTable("merchant_category");


