exports.up = (knex) =>
  knex.schema.createTable("account_delete_requests", (table) => {
    table.increments("id").unsigned().primary();
    table.string("type");
    table.text("reason").nullable();
    table.timestamp("lastRequestedAt").defaultTo(knex.fn.now());
    table
      .integer("userId")
      .references("users.id")
      .unsigned()
      .onDelete("CASCADE");
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });

exports.down = (knex) => knex.schema.dropTable("account_delete_requests");
