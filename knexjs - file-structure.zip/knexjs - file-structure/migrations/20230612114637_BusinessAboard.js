const { ACCOUNT_TYPE } = require("../src/common/constants");

exports.up = (knex) =>
  knex.schema
    .createTable("business_aboard", (table) => {
      table.increments("id").unsigned().primary();
      table.string("description");
      table.timestamp("createdAt").defaultTo(knex.fn.now());
      table.timestamp("updatedAt").nullable();
    })
    .then(async () => {
      await knex("business_aboard").insert([
        {
          description:
            "My company has at least 1 offshore legal entity among its shareholders",
        },
        {
          description:
            "My company has at least 1 branch outside of United Kingdom.",
        },
        {
          description:
            "My company is a subsidiary of another company outside of United Kingdom.",
        },
        {
          description:
            "My company has at least 1 legal representation office outside of United Kingdom.",
        },
      ]);
    });

exports.down = (knex) => knex.schema.dropTable("business_aboard");
