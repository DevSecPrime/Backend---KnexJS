exports.up = (knex) =>
  knex.schema.createTable("transaction_history", (table) => {
    table.increments("id").unsigned().primary();
    table
      .integer("userId")
      .unsigned()
      .references("id")
      .inTable("users")
      .onDelete("CASCADE");
    table.string("productIds").nullable();
    table.text("notes").nullable();
    table
      .enum("status", ["Pending", "Received", "Failed", "Refunded"])
      .defaultTo("Pending");
    table.string("amount").nullable();
    table.string("currency").nullable();
    table.string("stripePaymentId").nullable();
    table.string("moveneyFees").nullable();
    table.string("totalApplicationFees").nullable();
    table.string("stripeTax").nullable();
    table.string("stripeConnectAccountId").nullable();
    table.enum("paymentStatus", ["credit", "debit"]).nullable();
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").defaultTo(knex.fn.now());
  });

exports.down = (knex) => knex.schema.dropTable("transaction_history");
