exports.up = (knex) =>
  knex.schema.createTable("user_details", (table) => {
    table.increments("id").unsigned().primary();
    table
      .integer("userId")
      .references("users.id")
      .unsigned()
      .onDelete("CASCADE");

    table.string("countryOfBusiness", 191);
    table.string("currency", 191);
    table
      .integer("accountTypeId")
      .references("account_type.id")
      .unsigned()
      .onDelete("CASCADE");
    table.string("businessName", 191);
    table.string("firstName", 191);
    table.string("maidenName", 191);
    table.string("lastName", 191);
    table.string("email", 191);
    table.date("dateOfBirth");
    table.string("personalIDNumber", 191);
    table.string("uploadPersonalIDFrontSideImage", 191);
    table.string("uploadPersonalIDBackSideImage", 191);
    table.string("address", 191);
    // table.string("country", 191);
    table
      .integer("country")
      .references("countries.id")
      .unsigned()
      .onDelete("CASCADE");
    table
      .integer("state")
      .references("states.id")
      .unsigned()
      .onDelete("CASCADE");
    table.string("city", 191);
    table.string("postalCode", 191);
    table.string("accountHolderName", 191);
    table.string("sortCode", 191);
    table.string("accountNumber", 191);
    table.string("businessRegistrationNumber", 191);
    table.string("businessCategory", 191);
    table.string("websiteLink", 191);
    table.string("VATNumber", 191);
    table.string("businessAddress", 191);
    table
      .integer("businessCountry")
      .references("countries.id")
      .unsigned()
      .onDelete("CASCADE");
    table
      .integer("businessState")
      .references("states.id")
      .unsigned()
      .onDelete("CASCADE");
    table.string("businessCity", 191);
    table.string("businessPostalCode", 191);
    table.string("monthlySalesVolume", 191);
    table.string("numberOfTransactionPerMonth", 191);
    table.string("maximumSingleTransaction", 191);
    table.string("stripeConnectAccountId", 191);
    table.string("stripeFrontImage", 191);
    table.string("stripeBackImage", 191);
    table.string("businessRole", 191);
    table.string("ownerFullName", 191);
    table.string("ownerEmail", 191);
    table.string("ownerSignature", 191);
    table.string("ownerStripeSignature", 191);
    table.string("ownerPersonalID", 191);
    table.string("ownerFrontImage", 191);
    table.string("ownerBackImage", 191);
    table.string("ownerStripeFrontId", 191);
    table.string("ownerStripeBackId", 191);
    table.string("stripePersonId", 191);
    table.string("businessAboardIds", 191);
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").defaultTo(knex.fn.now());
    table.timestamp("expiresAt");
  });

exports.down = (knex) => knex.schema.dropTable("user_details");
