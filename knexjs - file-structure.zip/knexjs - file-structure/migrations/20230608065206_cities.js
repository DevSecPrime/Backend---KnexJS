const { City } = require("country-state-city");

exports.up = (knex) =>
  knex.schema.createTable("cities", (table) => {
    table.increments("id").unsigned().primary();
    table.string("name");
    table.string("stateCode");
    table.string("countryCode");
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });
// .then(async () => {
//   const cities = await City.getAllCities();

//   await Promise.all(
//     cities.map(async (city) => {
//       await knex("cities").insert([
//         {
//           name: city.name,
//           stateCode: city.stateCode,
//           countryCode: city.countryCode,
//         },
//       ]);
//     })
//   );
// });

exports.down = (knex) => knex.schema.dropTable("cities");
