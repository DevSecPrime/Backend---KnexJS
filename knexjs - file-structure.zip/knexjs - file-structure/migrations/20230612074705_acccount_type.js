const { ACCOUNT_TYPE } = require("../src/common/constants");

exports.up = (knex) =>
  knex.schema
    .createTable("account_type", (table) => {
      table.increments("id").unsigned().primary();
      table.string("name");
      table.enum("accountType", [
        ACCOUNT_TYPE.BUSINESS,
        ACCOUNT_TYPE.INDIVIDUAL,
      ]);
      table.timestamp("createdAt").defaultTo(knex.fn.now());
      table.timestamp("updatedAt").nullable();
    })
    .then(async () => {
      await knex("account_type").insert([
        {
          name: "Sole trader",
          accountType: ACCOUNT_TYPE.INDIVIDUAL,
        },
        {
          name: "Partnership",
          accountType: ACCOUNT_TYPE.BUSINESS,
        },
        {
          name: "Limited liability partnership",
          accountType: ACCOUNT_TYPE.BUSINESS,
        },
        {
          name: "Limited company",
          accountType: ACCOUNT_TYPE.BUSINESS,
        },
      ]);
    });

exports.down = (knex) => knex.schema.dropTable("account_type");
