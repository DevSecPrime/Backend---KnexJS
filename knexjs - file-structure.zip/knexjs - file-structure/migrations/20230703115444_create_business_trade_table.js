exports.up = (knex) =>
  knex.schema.createTable("business_trade", (table) => {
    table.increments("id").unsigned().primary();
    table.text("description").nullable();
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").defaultTo(knex.fn.now());
  });

exports.down = (knex) => knex.schema.dropTable("business_trade");
