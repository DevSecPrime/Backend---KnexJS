const { State } = require("country-state-city");

exports.up = (knex) =>
  knex.schema
    .createTable("states", (table) => {
      table.increments("id").unsigned().primary();
      table.string("name");
      table.string("code");
      table.string("countryCode");
      table.timestamp("createdAt").defaultTo(knex.fn.now());
      table.timestamp("updatedAt").nullable();
    })
    .then(async () => {
      const states = await State.getAllStates();

      await Promise.all(
        states.map(async (state) => {
          await knex("states").insert([
            {
              name: state.name,
              code: state.isoCode,
              countryCode: state.countryCode,
            },
          ]);
        })
      );
    });

exports.down = (knex) => knex.schema.dropTable("states");
